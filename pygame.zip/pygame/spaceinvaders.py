import pygame
import random

# Inicijalizacija pygame
pygame.init()

# Postavke prozora
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Space Invaders")

# Boje
WHITE = (255, 255, 255)
DIRTY_WHITE = (220, 220, 210)  # Prljavo bijela (svijetla siva)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Fontovi za tekst
font = pygame.font.Font(None, 74)
small_font = pygame.font.Font(None, 36)

# Klasa za eksploziju
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, size):
        super().__init__()
        # Pripremamo listu slika eksplozije. Imena slika: explosion1.png, explosion2.png, itd.
        self.frames = [pygame.image.load(f"explosion{frame}.png") for frame in range(1, 4)]  # explosion1.png, explosion2.png, ...
        
        # Mijenjamo veličinu eksplozije da odgovara veličini neprijatelja
        self.frames = [pygame.transform.scale(frame, (size, size)) for frame in self.frames]

        self.current_frame = 0
        self.image = self.frames[self.current_frame]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.animation_speed = 100  # U milisekundama (100 ms za svaku promjenu okvira)
        self.last_update = pygame.time.get_ticks()

    def update(self):
        # Provjera da li je prošlo dovoljno vremena za promjenu okvira
        now = pygame.time.get_ticks()
        if now - self.last_update > self.animation_speed:
            self.last_update = now
            self.current_frame += 1
            if self.current_frame >= len(self.frames):
                self.kill()  # Uništi eksploziju nakon što završi animacija
            else:
                self.image = self.frames[self.current_frame]  # Prebaci na sljedeći frame
                self.rect = self.image.get_rect(center=self.rect.center)  # Ponovno centriranje eksplozije

# Klasa za igrača
"""Klasa koja predstavlja igrača u igri.

    Igrač se može pomicati lijevo i desno te ispaljivati metke.
    """
class Player(pygame.sprite.Sprite):
    def __init__(self):
        """Inicijalizira igrača, postavlja početnu poziciju i učitava sliku."""
        super().__init__()
        self.image = pygame.image.load("player.png")  # Učitavanje slike igrača
        self.image = pygame.transform.scale(self.image, (50, 50))  # Promjena veličine na 50x50
        self.rect = self.image.get_rect()
        self.rect.center = (screen_width // 2, screen_height - 50)
        self.speed = 5

    def update(self):
        """Ažurira poziciju igrača na temelju korisničkog unosa."""
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < screen_width:
            self.rect.x += self.speed

    def fire(self):
        """Stvara metak koji igrač ispaljuje."""
        return Bullet(self.rect.centerx, self.rect.top)

# Klasa za neprijatelje
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("enemy.png")  # Učitavanje slike neprijatelja
        self.image = pygame.transform.scale(self.image, (50, 50))  # Promjena veličine na 50x50
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = 1
        self.direction = 1  # 1 za desno, -1 za lijevo

    def update(self):
        self.rect.x += self.speed * self.direction
        if self.rect.right >= screen_width or self.rect.left <= 0:
            self.direction *= -1
            self.rect.y += 30  # Kada dođe do ruba, pomiče se prema dolje

        # Nasumično odlučivanje hoće li neprijatelj ispaliti metak
        if random.randint(0, 700) < 2:  # 2% šanse da neprijatelj ispaljuje metak
            return EnemyBullet(self.rect.centerx, self.rect.bottom)  # Vraćamo neprijateljski metak
        return None

# Klasa za metke igrača
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((5, 10))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 7
 
    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()

# Klasa za neprijateljske metke
class EnemyBullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((5, 10))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 5

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > screen_height:
            self.kill()

# Funkcija za prikazivanje GAME OVER ekrana
def game_over_screen():
    screen.fill(DIRTY_WHITE)
    game_over_text = font.render("GAME OVER", True, WHITE)
    restart_text = small_font.render("Press SPACE to Restart", True, GREEN)
    screen.blit(game_over_text, (screen_width // 2 - game_over_text.get_width() // 2, screen_height // 3))
    screen.blit(restart_text, (screen_width // 2 - restart_text.get_width() // 2, screen_height // 2))
    pygame.display.flip()

# Funkcija za prikazivanje YOU WIN ekrana
def you_win_screen():
    screen.fill(BLACK)
    you_win_text = font.render("YOU WIN!", True, WHITE)
    restart_text = small_font.render("Press SPACE to Play Again", True, GREEN)
    screen.blit(you_win_text, (screen_width // 2 - you_win_text.get_width() // 2, screen_height // 3))
    screen.blit(restart_text, (screen_width // 2 - restart_text.get_width() // 2, screen_height // 2))
    pygame.display.flip()

# Funkcija za resetiranje igre
def reset_game():
    global player, player_group, enemy_group, bullet_group, enemy_bullet_group, explosion_group
    player = Player()
    player_group = pygame.sprite.Group()
    player_group.add(player)

    enemy_group = pygame.sprite.Group()
    bullet_group = pygame.sprite.Group()
    enemy_bullet_group = pygame.sprite.Group()
    explosion_group = pygame.sprite.Group()

    # Formacija neprijatelja (5x6)
    for row in range(5):
        for col in range(6):
            enemy = Enemy(col * 60 + 50, row * 60 + 50)  # Razmak od 60 piksela između neprijatelja
            enemy_group.add(enemy)

# Kreiranje objekata
reset_game()  # Početno postavljanje igre

# Glavna petlja igre
clock = pygame.time.Clock()
running = True
game_over = False
you_win = False
firing = False  # Indikator za stalno pucanje
last_fire_time = 0  # Početno vrijeme posljednjeg pucanja

# Vrijeme između pucanja (u milisekundama)
fire_rate = 250  # 400ms između pucanja

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                if game_over or you_win:
                    reset_game()  # Reset igre nakon Game Over ili You Win
                    game_over = False
                    you_win = False

                if not game_over and not you_win:
                    firing = True  # Počinje kontinuirano pucanje

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                firing = False  # Zaustavlja kontinuirano pucanje kad se tipka pusti

    # Ažuriranje objekata
    player_group.update()
    enemy_group.update()

    # Neprijatelji ispaljuju metke s nasumičnom šansom
    for enemy in enemy_group:
        enemy_bullet = enemy.update()
        if enemy_bullet:
            enemy_bullet_group.add(enemy_bullet)

    bullet_group.update()
    enemy_bullet_group.update()

    # Provjera sudara metaka igrača s neprijateljima
    for bullet in bullet_group:
        enemies_hit = pygame.sprite.spritecollide(bullet, enemy_group, True)
        for enemy in enemies_hit:
            bullet.kill()  # Igračev metak uništava neprijatelja
            explosion = Explosion(enemy.rect.centerx, enemy.rect.centery, enemy.rect.width)  # Kreiraj animaciju eksplozije
            explosion_group.add(explosion)

    # Provjera sudara neprijateljskih metaka s igračem
    for enemy_bullet in enemy_bullet_group:
        if pygame.sprite.collide_rect(enemy_bullet, player):
            game_over = True  # Igrač je pogođen, GAME OVER
            enemy_bullet.kill()  # Neprijateljski metak nestaje

    # Provjera da li su svi neprijatelji uništeni (YOU WIN)
    if len(enemy_group) == 0:
        you_win = True

    # Kontinuirano pucanje dok držimo SPACE, ali s intervalom
    if firing and not game_over and not you_win:
        current_time = pygame.time.get_ticks()  # Vremenski trenutak u milisekundama
        if current_time - last_fire_time >= fire_rate:  # Provjera da li je prošlo dovoljno vremena
            bullet = player.fire()
            bullet_group.add(bullet)
            last_fire_time = current_time  # Ažuriraj vrijeme posljednjeg pucanja

    # Crtanje objekata na ekranu
    if game_over:
        game_over_screen()  # Prikazivanje GAME OVER ekrana
    elif you_win:
        you_win_screen()  # Prikazivanje YOU WIN ekrana
    else:
        screen.fill(DIRTY_WHITE)
        player_group.draw(screen)
        enemy_group.draw(screen)
        bullet_group.draw(screen)
        enemy_bullet_group.draw(screen)
        explosion_group.update()  # Ažuriraj animacije eksplozija
        explosion_group.draw(screen)  # Crtaj eksplozije
        pygame.display.flip()

    # Održavanje 60 FPS
    clock.tick(60)

pygame.quit()
